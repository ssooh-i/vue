export default {
    template: `
        <div>
            <ul>
            <li><router-link to="/create">도서 등록</router-link></li>
            <li><router-link to="/list">도서 목록</router-link></li>
            </ul>
        </div>
    `
};