package com.ssafy.book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsVueBookApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
