export default {
  template: '<h2>지역 컴포넌트</h2>',
};
