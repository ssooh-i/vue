export default {
  props: ['member'],
  template: '#MemberView',
};
