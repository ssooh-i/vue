export default {
  template: '#MyComp',
  data() {
    return {
      msg: 'hello module component',
    };
  },
};
