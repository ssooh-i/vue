export const title = '계산기 모듈';

export function add(i, j) {
  return i + j;
}
export function sub(i, j) {
  return i - j;
}
