export const name = "안효인";
export const age = 30;

export function info() {
  return `이름 : ${name}, 나이 : ${age}`;
}

export class Student {}
