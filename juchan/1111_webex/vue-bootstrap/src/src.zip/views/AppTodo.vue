<template>
  <div id="todo">
    <todo-form></todo-form>
  </div>
</template>

<script>
import TodoForm from "@/components/TodoForm.vue";
export default {
  components: { TodoForm },
};
</script>

<style></style>
