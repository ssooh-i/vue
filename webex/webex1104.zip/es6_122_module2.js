const title = '계산기 모듈';

function add(i, j) {
  return i + j;
}
function sub(i, j) {
  return i - j;
}

export { title, add, sub };
