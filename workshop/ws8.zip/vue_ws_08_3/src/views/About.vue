<template>
  <div class="about">
    <h1>SSAFY WorkShop</h1>
  </div>
</template>
<script>
export default {
  name: "AboutView"
}
</script>

<style>

</style>
