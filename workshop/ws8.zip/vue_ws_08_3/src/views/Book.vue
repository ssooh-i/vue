<template>
  <div>
    <router-view />
  </div>
</template>

<script>
export default {
  name: "BookHome"
}
</script>

<style>

</style>