export default {
  template: `
    <div class="header">
        <a href="index.html"> <img src="./img/ssafy_logo.png" class="ssafy_logo" /></a>
        <p class="logo">도서관리</p>
    </div>`
};
