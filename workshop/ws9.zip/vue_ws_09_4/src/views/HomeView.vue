<template>
  <main class="index-main">
    <div class="main-menu">
      <ul>
        <li>
          <router-link to="/restaurant/create"
            ><a href="#">맛집등록</a></router-link
          >
        </li>
        <li>
          <router-link to="/restaurant"><a href="#">맛집리스트</a></router-link>
        </li>
      </ul>
    </div>
  </main>
</template>
<script>
export default {};
</script>
