<template>
  <footer class="footer">
    <ul class="list">
      <li>
        <a href="Personal information processing policy">개인정보처리방침</a>
      </li>
      <li>
        <a href="Terms of Service">이용약관</a>
      </li>
      <li>
        <a href="Directions">오시는길</a>
      </li>
      <li>Created by the SSAFY team &middot; &copy; 2022</li>
    </ul>
  </footer>
</template>
<script>
export default {
  name: "Footer",
};
</script>
