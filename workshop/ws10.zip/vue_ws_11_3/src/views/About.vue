<template>
  <b-container class="bv-example-row mt-3">
    <b-row>
      <b-col></b-col>
      <b-col cols="10">
        <b-jumbotron bg-variant="dark" text-variant="white" border-variant="dark">
          <template #header>SSAFY 도서 관리</template>

          <template #lead>
            About
          </template>

          <hr class="my-4" />

          <p>
            무엇이든 물어보세요.
          </p>
        </b-jumbotron>
      </b-col>
      <b-col></b-col>
    </b-row>
  </b-container>
</template>

<script>
export default {
  name: "AboutView"
}
</script>

<style>

</style>
