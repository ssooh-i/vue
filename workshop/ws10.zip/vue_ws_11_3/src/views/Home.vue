<template>
  <b-container class="bv-example-row mt-3">
    <b-row>
      <b-col></b-col>
      <b-col cols="10">
        <b-jumbotron bg-variant="muted" text-variant="dark" border-variant="dark">
          <template #header>SSAFY 도서 관리</template>

          <template #lead>
            SSAFY 도서관리 사이트입니다.
          </template>

          <hr class="my-4" />

          <p>
            좋은 도서정보 얻어가세요.
          </p>
        </b-jumbotron>
      </b-col>
      <b-col></b-col>
    </b-row>
  </b-container>
</template>
<script>
export default {
  name: "HomeView"
}
</script>

<style>

</style>
