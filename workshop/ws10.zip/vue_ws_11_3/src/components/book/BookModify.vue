<template>
  <div>
    <write-form type="modify" />
  </div>
</template>

<script>
import WriteForm from "@/components/book/include/WriteForm.vue";

export default {
  name: "BookModify",
  components: {
    WriteForm
  }
};
</script>
