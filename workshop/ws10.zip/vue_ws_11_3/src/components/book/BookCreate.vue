<template>
  <div>
    <write-form type="create" />
  </div>
</template>

<script>
import WriteForm from "@/components/book/include/WriteForm.vue";

export default {
  name: "BookCreate",
  components: {
    WriteForm
  }
};
</script>
