<template>
  <div>{{ attractionInfo }}</div>
</template>

<script>
export default {
  name: "MainContent2",
  props: {
    attractionInfo: String,
  },
};
</script>

<style></style>
