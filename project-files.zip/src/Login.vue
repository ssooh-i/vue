<template>
	<div>
		<h1>Login</h1>
		<router-link to="/">Home</router-link>
	</div>
</template>
