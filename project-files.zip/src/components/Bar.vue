<template>
	<h1>Bar Page</h1>
</template>
